# WindUI Custom - abas horizontais e interface compacta

Adaptacao do projeto aberto [Footagesus/WindUI](https://github.com/Footagesus/WindUI), versao base 1.6.66 (licenca MIT).

## Arquivos entregues

- `WindUI_Custom.lua`: biblioteca completa, pronta para hospedar no GitHub.
- `WindUI_Custom_Teste.lua`: teste standalone; basta executar, sem precisar hospedar a biblioteca primeiro.

## Exemplo: menu superior

Depois de enviar `WindUI_Custom.lua` ao seu GitHub, substitua a URL pelo endereco RAW do arquivo:

```lua
local WindUI = loadstring(game:HttpGet("COLE_AQUI_URL_RAW_DO_SEU_GITHUB"))()

local Window = WindUI:CreateWindow({
    Title = "Meu Hub",
    TabsPosition = "Top", -- "Top" ou "Left"
    Compact = true,
    Size = UDim2.fromOffset(520, 360),
    MinSize = Vector2.new(420, 300),
    TopTabWidth = 116,
    TopTabHeight = 40,
    SideBarWidth = 155, -- vale para "Left"
})

local Principal = Window:Tab({ Title = "Principal", Icon = "house" })
Principal:Button({ Title = "Teste", Callback = function() print("OK") end })
```

## Opcoes novas

| Campo | Tipo | Funcao |
| --- | --- | --- |
| `TabsPosition` | `"Left"` ou `"Top"` | Define onde aparecem as abas (padrao: Left). |
| `Compact` | boolean | Usa margens, dimensoes padrao e menu mais compactos. |
| `TopTabWidth` | number | Largura padrao das abas horizontais (minimo 80). |
| `TopTabHeight` | number | Altura da faixa horizontal (minimo 34). |
| `Width` (dentro de `Window:Tab`) | number | Largura individual de uma aba horizontal. |

`Size`, `MinSize`, `MaxSize` e `SideBarWidth` sao configuracoes originais da WindUI.

## Comportamento

- Left preserva a navegacao original com abas e secoes expansivas.
- Top apresenta as abas em linha com rolagem horizontal em telas pequenas.
- Abas longas ficam truncadas com reticencias; aumente `Width` individualmente quando precisar.
- Com Top, as secoes (`Window:Section`) aparecem como titulos da faixa, e suas abas ficam ao lado (sem expansao vertical).
- Com Top, o cartao de usuario lateral e ocultado para evitar sobreposicoes.
- A barra de busca, quando ativada, aparece a direita das abas no topo.
- A orientacao e definida ao criar a janela; nao muda dinamicamente numa janela ja aberta.

## Limites de teste

O arquivo foi compilado com o mesmo empacotador usado no projeto oficial e a estrutura foi verificada estaticamente. O comportamento visual e de toque ainda precisa ser conferido executando o teste dentro do Roblox (PC e celular).

O arquivo e uma modificacao independente e nao uma versao publicada pelos mantenedores oficiais.
