-- MIKOTOH UI 4.5.1 | EXEMPLO COMPLETO
-- Primeiro envie MIKOTOH_UI_4_0.lua para a raiz da branch main do seu GitHub.
-- Este exemplo carrega a biblioteca publicada e mostra os 30 temas e 9 pets ficticios.
local url = "https://raw.githubusercontent.com/discordtiktok76-ctrl/MIKOTO-LIBRARY-UI/refs/heads/main/MIKOTOH_UI_4_0.lua"
local ok, source = pcall(function() return game:HttpGet(url) end)
assert(ok, "Nao foi possivel baixar a biblioteca: " .. tostring(source))
local chunk, problem = loadstring(source)
assert(chunk, "Erro ao carregar a biblioteca. Confira a URL e o arquivo publicado: " .. tostring(problem))
local Library = chunk()
assert(type(Library)=="table" and type(Library.CreateWindow)=="function", "O arquivo publicado precisa retornar a biblioteca MIKOTOH.")

local demoAccent = {
    Original="#FF6565",
    Dark="#B0C6DF",
    Rose="#F4A3C4",
    Roxo="#C6A0FA",
    Verde="#73E0A1",
    VermelhoEscuro="#ED8995",
    Azul="#83CCFF",
    Preto="#BAC0CC",
    Lilas="#D8BEF5",
    Dourado="#F1CF83",
    Ciano="#79E2F3",
    Laranja="#FFC087",
    Turquesa="#81E5CB",
    Magenta="#F99ADF",
    Prata="#D5E0EC",
    Ambar="#F3C86B",
    Marinho="#83ACDF",
    Menta="#B5F1D2",
    Coral="#FFC1AD",
    Safira="#9BB9FF",
    Esmeralda="#8CEAC0",
    Lavanda="#DDC5FC",
    Carmim="#F3A3BA",
    Lima="#E4F598",
    Cobre="#F7BF91",
    Gelo="#D4F3FF",
    Grafite="#CDD8E1",
    Violeta="#E0A6FC",
    RosaNeon="#FFC0ED",
    Oceano="#9DE0F4",
}
local function createSamplePets()
    local container=Instance.new("Folder")
    container.Name="MIKOTOH_Pets_Demonstracao"
    local definitions={
        {Id="raposa_solar",Name="Raposa Solar",Kind="Fox",Rarity="Raro",RarityNumber=2,Value=180,
            Color=Color3.fromRGB(244,125,53),Accent="#FFB46A"},
        {Id="gato_nebuloso",Name="Gato Nebuloso",Kind="Cat",Rarity="Epico",RarityNumber=3,Value=390,
            Color=Color3.fromRGB(145,93,218),Accent="#C5A4FF"},
        {Id="dragao_jade",Name="Dragao de Jade",Kind="Dragon",Rarity="Lendario",RarityNumber=5,Value=1520,
            Color=Color3.fromRGB(43,185,117),Accent="#8EF7C1"},
        {Id="coelho_lunar",Name="Coelho Lunar",Kind="Rabbit",Rarity="Raro",RarityNumber=2,Value=210,
            Color=Color3.fromRGB(151,197,255),Accent="#D0E7FF"},
        {Id="robo_safira",Name="Robo Safira",Kind="Robot",Rarity="Epico",RarityNumber=3,Value=470,
            Color=Color3.fromRGB(63,133,226),Accent="#93D8FF"},
        {Id="fantasma_carmim",Name="Fantasma Carmim",Kind="Ghost",Rarity="Secreto",RarityNumber=6,Value=2800,
            Color=Color3.fromRGB(229,67,103),Accent="#FF9BB4"},
        {Id="tartaruga_dourada",Name="Tartaruga Dourada",Kind="Turtle",Rarity="Lendario",RarityNumber=5,Value=1350,
            Color=Color3.fromRGB(214,170,59),Accent="#FFE18B"},
        {Id="urso_coral",Name="Urso Coral",Kind="Bear",Rarity="Comum",RarityNumber=1,Value=95,
            Color=Color3.fromRGB(235,124,124),Accent="#FFC2A9"},
        {Id="estrela_cosmica",Name="Estrela Cosmica",Kind="Star",Rarity="Secreto",RarityNumber=6,Value=3100,
            Color=Color3.fromRGB(103,98,232),Accent="#B9B3FF"},
    }
    local function piece(model,name,shape,size,position,color,material)
        local object=Instance.new("Part")
        object.Name=name
        object.Shape=shape or Enum.PartType.Block
        object.Size=size
        object.CFrame=position
        object.Color=color
        object.Material=material or Enum.Material.SmoothPlastic
        object.Anchored=true
        object.CanCollide=false
        object.CanTouch=false
        object.Parent=model
        return object
    end
    local items={}
    for sampleIndex,info in ipairs(definitions) do
        local model=Instance.new("Model")
        model.Name=info.Id
        model.Parent=container
        local ball=Enum.PartType.Ball
        local bodyShape=info.Kind=="Robot" and Enum.PartType.Block or ball
        local body=piece(model,"Body",bodyShape,Vector3.new(1.45,1.3,1.15),
            CFrame.new(0,0,0),info.Color)
        local head=piece(model,"Head",bodyShape,Vector3.new(1.1,1.02,1),
            CFrame.new(0,0.64,0.35),info.Color:Lerp(Color3.new(1,1,1),0.12))
        local eyeColor=info.Kind=="Ghost" and Color3.fromRGB(255,245,255)
            or Color3.fromRGB(22,27,48)
        for _,side in ipairs({-1,1}) do
            piece(model,"Eye",ball,Vector3.new(0.16,0.2,0.1),
                CFrame.new(side*0.23,0.75,0.84),eyeColor,Enum.Material.Neon)
            piece(model,"Foot",ball,Vector3.new(0.42,0.31,0.52),
                CFrame.new(side*0.43,-0.7,0.28),info.Color)
        end
        local earLength=info.Kind=="Rabbit" and 0.92 or 0.43
        if info.Kind~="Ghost" and info.Kind~="Turtle" and info.Kind~="Star" then
            for _,side in ipairs({-1,1}) do
                piece(model,"Ear",Enum.PartType.Block,Vector3.new(0.28,earLength,0.3),
                    CFrame.new(side*0.38,1.25+(earLength-0.43)*0.4,0.13)
                        * CFrame.Angles(0,0,math.rad(side*18)),info.Color:Lerp(Color3.new(1,1,1),0.35))
            end
        end
        if info.Kind=="Fox" or info.Kind=="Cat" then
            piece(model,"Tail",ball,Vector3.new(0.45,0.46,1.3),
                CFrame.new(0.58,-0.32,-0.9)*CFrame.Angles(0,math.rad(22),math.rad(25)),
                info.Color:Lerp(Color3.new(1,1,1),0.28))
        elseif info.Kind=="Dragon" then
            for _,side in ipairs({-1,1}) do
                piece(model,"Wing",Enum.PartType.Block,Vector3.new(0.16,1,1.05),
                    CFrame.new(side*0.84,0.34,-0.27)*CFrame.Angles(0,0,math.rad(side*30)),
                    Color3.fromRGB(20,126,97))
            end
            piece(model,"Horns",Enum.PartType.Block,Vector3.new(0.26,0.46,0.28),
                CFrame.new(0,1.43,0),Color3.fromRGB(187,255,194),Enum.Material.Neon)
        elseif info.Kind=="Rabbit" then
            piece(model,"PomPom",ball,Vector3.new(0.45,0.45,0.45),
                CFrame.new(0,-0.25,-0.74),Color3.fromRGB(241,247,255))
        elseif info.Kind=="Robot" then
            piece(model,"Antenna",Enum.PartType.Block,Vector3.new(0.12,0.47,0.12),
                CFrame.new(0,1.37,0),Color3.fromRGB(41,54,83))
            piece(model,"Signal",ball,Vector3.new(0.25,0.25,0.25),
                CFrame.new(0,1.66,0),Color3.fromRGB(122,238,255),Enum.Material.Neon)
        elseif info.Kind=="Ghost" then
            body.Transparency=0.2
            head.Transparency=0.15
            piece(model,"Aura",ball,Vector3.new(0.5,0.55,0.5),
                CFrame.new(0,-0.9,0),Color3.fromRGB(255,133,165),Enum.Material.Neon)
        elseif info.Kind=="Turtle" then
            piece(model,"Shell",ball,Vector3.new(1.65,0.91,1.45),
                CFrame.new(0,0.18,-0.25),Color3.fromRGB(119,106,45))
        elseif info.Kind=="Bear" then
            piece(model,"Muzzle",ball,Vector3.new(0.5,0.33,0.29),
                CFrame.new(0,0.42,0.92),Color3.fromRGB(255,206,179))
        elseif info.Kind=="Star" then
            for index=0,4 do
                piece(model,"Ray",Enum.PartType.Block,Vector3.new(0.2,0.85,0.3),
                    CFrame.new(0,0.62,0)*CFrame.Angles(0,0,index*math.pi*2/5)
                        * CFrame.new(0,0.66,0),Color3.fromRGB(199,193,255),Enum.Material.Neon)
            end
        end
        -- Exercita a clonagem de modelos nao arquivaveis sem alterar o jogo.
        if info.Kind=="Dragon" then model.Archivable=false end
        if info.Kind=="Robot" then head.Archivable=false end
        table.insert(items,{Id=info.Id,Name=info.Name,Model=model,Rarity=info.Rarity,
            RarityNumber=info.RarityNumber,Value=info.Value,Income=info.Value,Accent=info.Accent,
            Scale=0.85+sampleIndex*0.17,Weight=4.2+sampleIndex*3.75,
            Equipped=sampleIndex<=2,Status=sampleIndex<=2 and "Equipped" or "In inventory",
            Mutations=sampleIndex==3 and {"Golden"} or sampleIndex==9 and {"Rainbow"}
                or sampleIndex==6 and {"Monstrous"} or {},
            Details="Tap a pet below to preview it"})
    end
    return container,items
end

-- TESTE COMPLETO V3: biblioteca embutida. Cole este arquivo inteiro no executor.
-- Esta primeira aba funciona em qualquer jogo e nao depende de pets reais.
local function buildDemo()
    local env = getgenv and getgenv() or _G
    if env.MIKOTOH_DEMO and not env.MIKOTOH_DEMO._destroyed then
        pcall(function() env.MIKOTOH_DEMO:Destroy() end)
    end
    if env.MIKOTOH_TEST_MODELS then
        pcall(function() env.MIKOTOH_TEST_MODELS:Destroy() end)
    end

    local window = Library:CreateWindow({
        Name="MIKOTOH TESTE COMPLETO V3", DefaultTab="Pets 3D", Theme="Original",
        OpenButton={Mode="Original"},
    })
    env.MIKOTOH_DEMO = window
    local firstTab = window:GetDefaultTab()
    local themeNames = Library:GetThemes()
    local colorSection = firstTab:CreateSection({Name="TESTE V3 - Escolher 30 cores",Expanded=true})
    local themeStatus = colorSection:CreateText({Name="Tema aplicado",Text="Original (1/30)"})
    local colorPageStatus
    local function applyTheme(name)
        local ok, problem = pcall(function() window:SetTheme(name) end)
        if ok then
            local index = table.find(themeNames,name) or 1
            themeStatus:Set("Tema aplicado: " .. name .. " (" .. index .. "/" .. #themeNames .. ")",false)
            if colorPageStatus then colorPageStatus:Set("Tema aplicado: " .. name .. " (" .. index .. "/30)",false) end
        else
            themeStatus:Set("ERRO na cor " .. tostring(name) .. ": " .. tostring(problem):sub(1,90),false)
            warn("MIKOTOH V3 tema:",problem)
        end
    end
    local choice = colorSection:CreateDropdown({
        Name="Escolha qualquer tema",Options=themeNames,Default="Original",Callback=applyTheme,
    })
    local function choose(name)
        choice:Set(name,false)
        applyTheme(name)
    end
    colorSection:CreateButton({Name="Trocar para proxima cor",ButtonText="Proximo tema",
        Callback=function()
            local index = table.find(themeNames,choice:Get()) or 1
            choose(themeNames[index % #themeNames + 1])
        end})

    local petSection = firstTab:CreateSection({Name="PETS 3D - nove modelos ficticios",Expanded=true})
    local petStatus = petSection:CreateText({Name="Status do preview 3D",Text="Criando 9 pets ficticios..."})
    local models, petItems
    local petsReady, petsProblem = pcall(function() models,petItems=createSamplePets() end)
    if petsReady then
        env.MIKOTOH_TEST_MODELS = models
        window.Gui.Destroying:Connect(function()
            if models then models:Destroy() end
            if env.MIKOTOH_TEST_MODELS == models then env.MIKOTOH_TEST_MODELS = nil end
        end)
        local gallery
        petSection:CreateDropdown({Name="Sort By",Options={"Value","Rarity","Name"},Default="Value",
            Callback=function(value) if gallery then gallery:SetSort(value) end end})
        petSection:CreateToggle({Name="Preview Card",Default=true,
            Callback=function(value) if gallery then gallery:SetPreviewVisible(value) end end})
        local galleryReady, galleryProblem = pcall(function()
            gallery=petSection:CreatePetGallery({
                Name="Galeria de pets ficticios", Title="Pet Review",
                Items=petItems, PageSize=9, Sort="Value", Spin=true, SelectedId="estrela_cosmica",
                PreviewCard=true,GroupByStatus=true,
                OnError=function(problem) petStatus:Set("Erro no modelo 3D: " .. problem,false) end,
                OnSelect=function(item)
                    petStatus:Set("Selecionado: " .. item.Name .. " (" .. item.Rarity .. ")",false)
                end,
            })
        end)
        if galleryReady then
            window.PetGallery = gallery
            petStatus:Set("9 pets ficticios. Toque numa linha para selecionar; o preview permanece no topo.",false)
            petSection:CreateToggle({Name="Girar previews 3D",Default=true,
                Callback=function(value) gallery:SetSpin(value) end})
            petSection:CreateButton({Name="Recarregar previews",ButtonText="Atualizar pets 3D",
                Callback=function() gallery:Refresh() end})
            petSection:CreateDropdown({Name="Pets por pagina",Options={"Todos (9)","6 por pagina"},Default="Todos (9)",
                Callback=function(value) gallery:SetPageSize(value=="6 por pagina" and 6 or 9) end})
            -- Confirma se o WorldModel realmente recebeu clones, e mostra falhas na interface.
            task.delay(8,function()
                if window._destroyed or gallery._destroyed then return end
                local visibleItems=gallery:_filtered()
                if #visibleItems==0 then
                    petStatus:Set("Nenhum resultado para esta busca.",false)
                    return
                end
                local mounted=0
                for _,descendant in ipairs(gallery.Instance:GetDescendants()) do
                    if descendant:IsA("ViewportFrame") then
                        local world=descendant:FindFirstChildOfClass("WorldModel")
                        if world and #world:GetChildren()>0 then mounted+=1 end
                    end
                end
                if mounted>0 then
                    petStatus:Set("9 pets ficticios | " .. mounted .. " previews 3D carregados. Toque nas linhas da lista.",false)
                else
                    petStatus:Set("ERRO: 0 previews 3D carregados. Confira o console do executor.",false)
                    warn("MIKOTOH V3: a galeria existe, mas nenhum WorldModel recebeu um pet.")
                end
            end)
        else
            petStatus:Set("ERRO ao montar galeria 3D: " .. tostring(galleryProblem):sub(1,105),false)
            warn("MIKOTOH V3 galeria:",galleryProblem)
        end
    else
        petStatus:Set("ERRO ao criar pets ficticios: " .. tostring(petsProblem):sub(1,110),false)
        warn("MIKOTOH V3 pets:",petsProblem)
    end

    local function optional(label, fn)
        local ok, problem = pcall(fn)
        if not ok then
            warn("MIKOTOH V3 " .. label .. ": " .. tostring(problem))
            -- A falha fica no primeiro quadro mesmo se uma aba secundaria nao terminar.
            themeStatus:Set("TESTE V3 | falha em " .. label .. ": " .. tostring(problem):sub(1,75),false)
        end
    end

    optional("Cores",function()
        local tab=window:CreateTab({Name="Cores"})
        local intro=tab:CreateSection({Name="30 cores - toque em Aplicar",Expanded=true})
        colorPageStatus=intro:CreateText({Name="Tema ativo",Text="Tema aplicado: Original (1/30)"})
        local section
        for index,name in ipairs(themeNames) do
            if (index-1)%6==0 then
                section=tab:CreateSection({Name=string.format("Temas %02d a %02d",index,math.min(index+5,#themeNames)),Expanded=true})
            end
            section:CreateButton({Name="Tema " .. name,ButtonText="Aplicar " .. name,
                TextColor=demoAccent[name],Callback=function() choose(name) end})
        end
    end)

    optional("Componentes",function()
        local tab=window:CreateTab({Name="Componentes"})
        local basics=tab:CreateSection({Name="Controles interativos",Expanded=true})
        local feedback=basics:CreateText({Name="Resultado",Text="Toque nos controles para testar."})
        basics:CreateButton({Name="Botao",ButtonText="Testar botao",Callback=function()
            feedback:Set("Botao pressionado",false) end})
        local dependent=basics:CreateToggle({Name="Mostrar campo extra",Default=false,
            Callback=function(value) feedback:Set("Toggle: " .. tostring(value),false) end})
        basics:CreateInput({Name="Campo condicional",Placeholder="Ative o toggle acima",
            ShowWhen=dependent,Callback=function(value) feedback:Set("Campo: " .. value,false) end})
        basics:CreateSlider({Name="Slider numerico",Min=0,Max=100,Default=35,Increment=5,
            Callback=function(value) feedback:Set("Slider: " .. tostring(value),false) end})
        basics:CreateTextSlider({Name="Slider com nomes",Values={"Baixo","Medio","Alto"},
            Default="Medio",Callback=function(value) feedback:Set("Nivel: " .. value,false) end})
        basics:CreateDropdown({Name="Dropdown",Options={"Raposa","Dragao","Coelho"},
            Default="Raposa",Callback=function(value) feedback:Set("Escolhido: " .. value,false) end})
        basics:CreateMultiDropdown({Name="Multi Dropdown",
            Options={"Comum","Raro","Epico","Lendario","Secreto"},Default={"Raro"},
            Callback=function(values) feedback:Set("Raridades: " .. table.concat(values,", "),false) end})
        basics:CreateActionDropdown({Name="Dropdown com aplicar",
            Options={"Original","Azul","Rose"},Default="Original",ButtonText="Aplicar",
            Callback=function(value) choose(value);feedback:Set("Aplicado: " .. value,false) end})
        local content=tab:CreateSection({Name="Conteudo e outro preview",Expanded=true})
        content:CreateParagraph({Name="Paragrafo",Title="Teste de texto",
            Text="Confira cores, controles e nove pets ficticios em 3D na aba Pets 3D."})
        if petItems then
            content:CreateCanvas({Name="Canvas 3D",Title="Segundo preview 3D",Layout="free",
                Style={MinLines=6,MaxLines=8},Build=function(surface)
                    surface:Model({Name="Dragao de Jade",Model=petItems[3].Model,
                        X=0,Y=0.25,WidthScale=0.42,Height=5.4,Spin=true})
                    surface:Text({Name="Legenda",Text="Dragao ficticio em outro Canvas",
                        X=9,Y=1.1,WidthScale=0.54,Height=3,Wrap=true})
                    surface:SetContentLines(6)
                end})
        end
    end)

    optional("Farm",function()
        local tab=window:CreateTab({Name="Farm"})
        local section=tab:CreateSection({Name="Auto Steal - somente interface",Expanded=true})
        local auto=section:CreateToggle({Name="Auto Steal",Default=false,
            Callback=function(value) print("Auto Steal (UI):",value) end})
        local instant=section:CreateToggle({Name="Instant Steal",Default=false,
            Callback=function(value) print("Instant Steal (UI):",value) end})
        local panel=window:CreateEggPanel({Enabled=false,
            AutoStealState=auto:GetState(),InstantStealState=instant:GetState(),
            OnAction=function(item) print("Steal (UI):",item.Id) end,
            OnPriority=function(item) print("Priority (UI):",item.Id) end,
            OnCancel=function(item) print("Cancel (UI):",item.Id) end,
            OnMove=function(item,delta) print("Move (UI):",item.Id,delta) end,
        })
        local sort=section:CreateDropdown({Name="Steal Priority",Options=panel:GetSortModes(),
            Default="Highest Value",Callback=function(mode) panel:SetSort(mode) end})
        panel.Config.OnSort=function(mode) if sort:Get()~=mode then sort:Set(mode,false) end end
        section:CreateSlider({Name="Tween Speed",Min=50,Max=120,Default=100,Increment=1,Unit="%"})
        section:CreateSlider({Name="Carry Speed",Min=80,Max=120,Default=100,Increment=1,Unit="%"})
        section:CreateAntiGuardPanel({Name="Anti Guard Panel",Default=false,Value=false})
        section:CreateText({Name="Painel do jogo",Text=panel:IsReady()
            and "Painel original localizado." or "Painel original exige HUD ActivePets do jogo."})
    end)

    window:SelectTab(firstTab)
    window:Finalize()
    print("MIKOTOH TESTE COMPLETO V3: abra Pets 3D e Cores. 30 temas, 9 pets ficticios.")
    return window
end

local ok, problem = xpcall(buildDemo, function(err)
    local trace = debug and debug.traceback and debug.traceback(tostring(err),2) or tostring(err)
    warn("MIKOTOH TESTE COMPLETO V3: " .. trace)
    return trace
end)
if not ok then error(problem,0) end
